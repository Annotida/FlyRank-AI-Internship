"use client";
import {Handle,Position,type NodeProps} from "@xyflow/react";
import type {WorkflowNode} from "@/types/workflow";
export default function DecisionNode({data}:NodeProps<WorkflowNode>){
 const status=data.status||"idle";
 return <div className={`w-72 rounded-xl border p-3 shadow-xl bg-slate-900 ${status==='running'?'border-yellow-400':status==='yes'?'border-green-400':status==='no'?'border-red-400':status==='error'?'border-orange-400':'border-slate-600'}`}>
  <Handle type="target" position={Position.Left}/>
  <div className="flex justify-between items-center"><strong>{data.label}</strong><span className="text-xs opacity-70">{status}</span></div>
  <p className="text-xs text-slate-300 mt-2">{data.prompt||"No prompt yet"}</p>
  <div className="flex justify-between mt-3 text-xs"><span className="text-green-300">YES</span><span className="text-red-300">NO</span></div>
  <Handle type="source" id="yes" position={Position.Right} style={{top:"35%"}}/>
  <Handle type="source" id="no" position={Position.Right} style={{top:"70%"}}/>
 </div>
}
