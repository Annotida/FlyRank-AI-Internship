import type {Workflow} from "@/types/workflow";
export function normalizeWorkflow(input:unknown):Workflow{
  const w=input as Workflow;
  if(!w || !Array.isArray(w.nodes) || !Array.isArray(w.edges)) throw new Error("Invalid workflow");
  return w;
}
export function getStartNode(w:Workflow){
  const incoming=new Set(w.edges.map(e=>e.target));
  return w.nodes.find(n=>!incoming.has(n.id));
}
export function getNext(w:Workflow,nodeId:string,result:"YES"|"NO"){
  return w.edges.find(e=>e.source===nodeId && (e.label===result || e.sourceHandle===result.toLowerCase()))?.target;
}
