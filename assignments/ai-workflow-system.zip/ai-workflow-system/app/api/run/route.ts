import {NextResponse} from "next/server";
import {inngest} from "@/lib/inngest";
import {normalizeWorkflow} from "@/lib/workflow";
export async function POST(req:Request){try{const {workflow,context=""}=await req.json();normalizeWorkflow(workflow);const sent=await inngest.send({name:"workflow/run.requested",data:{workflow,context}});return NextResponse.json({ok:true,eventId:sent.ids?.[0]});}catch(e){return NextResponse.json({ok:false,error:e instanceof Error?e.message:"Unknown error"},{status:400});}}
