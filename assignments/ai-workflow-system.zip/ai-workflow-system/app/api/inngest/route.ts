import {serve} from "@inngest/next";
import {inngest} from "@/lib/inngest";
import {getOpenAI} from "@/lib/openai";
import {getStartNode,getNext} from "@/lib/workflow";
import type {Workflow} from "@/types/workflow";

const runWorkflow=inngest.createFunction({id:"execute-ai-workflow",retries:2}, {event:"workflow/run.requested"}, async ({event,step})=>{
  const {workflow,context}=event.data as {workflow:Workflow;context:string};
  const logs:{nodeId:string;label:string;result?:"YES"|"NO";error?:string;timestamp:string}[]=[];
  let current=getStartNode(workflow);
  if(!current) throw new Error("Workflow has no start node");
  let guard=0;
  while(current && guard++<100){
    const node=current;
    const result=await step.run(`decision-${node.id}`,async()=>{
      const openai=getOpenAI();
      const completion=await openai.chat.completions.create({
        model:process.env.OPENAI_MODEL||"gpt-4o-mini",
        temperature:0,
        messages:[
          {role:"system",content:"You are a strict workflow decision engine. Return exactly YES or NO and nothing else."},
          {role:"user",content:`Context:\n${context}\n\nDecision question:\n${node.data.prompt}\n\nReturn exactly YES or NO.`}
        ],
        max_tokens:5
      });
      const raw=(completion.choices[0]?.message?.content||"").trim().toUpperCase();
      if(raw!=="YES"&&raw!=="NO") throw new Error(`Model returned invalid decision: ${raw}`);
      return raw as "YES"|"NO";
    });
    logs.push({nodeId:node.id,label:node.data.label,result,timestamp:new Date().toISOString()});
    const nextId=getNext(workflow,node.id,result);
    current=nextId?workflow.nodes.find(n=>n.id===nextId):undefined;
  }
  return {logs,completed:!current};
});
export const {GET,POST,PUT}=serve({client:inngest,functions:[runWorkflow]});
