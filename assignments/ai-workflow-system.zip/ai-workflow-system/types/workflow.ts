export type DecisionNodeData={label:string;prompt:string;status?:"idle"|"running"|"yes"|"no"|"error"};
export type WorkflowNode={id:string;type:"decision";position:{x:number;y:number};data:DecisionNodeData};
export type WorkflowEdge={id:string;source:string;target:string;label?:"YES"|"NO";sourceHandle?:"yes"|"no"};
export type Workflow={nodes:WorkflowNode[];edges:WorkflowEdge[]};
export type ExecutionLog={nodeId:string;label:string;result?:"YES"|"NO";error?:string;timestamp:string};
