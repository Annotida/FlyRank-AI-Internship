# AI Decision Workflow System

A visual YES/NO AI workflow builder using **Next.js**, **React Flow**, **Inngest**, and the **OpenAI API**.

## Features
- Visual decision-node workflow editor
- YES/NO handles and branching edges
- Editable prompts
- Local workflow persistence
- JSON export
- Inngest event-driven execution
- OpenAI-powered strict YES/NO decisions
- Step retries through Inngest
- Execution status/log panel foundation

## Requirements
- Node.js 20+
- npm
- OpenAI API key

## Setup
```bash
npm install
copy .env.example .env.local
```
On macOS/Linux use:
```bash
cp .env.example .env.local
```
Add your `OPENAI_API_KEY` to `.env.local`.

## Run
Terminal 1:
```bash
npm run dev
```
Terminal 2:
```bash
npx inngest-cli@latest dev -u http://localhost:3000/api/inngest
```
Then open http://localhost:3000 and the Inngest Dev Server URL printed by the CLI.

## How it works
1. The frontend stores the graph as nodes and edges.
2. Clicking **Run workflow** sends the graph/context to `/api/run`.
3. The API sends a `workflow/run.requested` event to Inngest.
4. Inngest executes each decision node as a durable step.
5. OpenAI is asked for exactly `YES` or `NO`.
6. The selected YES/NO edge determines the next node.

## Important
The current frontend queues the workflow through Inngest. For production-quality live execution visualization, add an execution-status store (for example PostgreSQL/Redis) or subscribe to Inngest run events and stream status to the browser.

## Suggested test
Use the default context and confirm:
- `Support request?` returns YES
- It traverses to `Support path`
- `Support path` evaluates its own question

Do not commit `.env.local` or API keys.
